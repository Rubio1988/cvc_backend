# CNC VisionCut Backend - FastAPI con Alembic y JWT Auth
# --------------------------------------------------------
# Proyecto: CNC VisionCut
# Descripción: API REST para carga de diseños, parseo CAD/CV, simulación, generación de G-code
#    y protección con OAuth2/JWT.

from fastapi import FastAPI, Depends, HTTPException, status, UploadFile, File
from fastapi.responses import JSONResponse, FileResponse
from fastapi.security import OAuth2PasswordBearer, OAuth2PasswordRequestForm
from pydantic import BaseModel, Field, validator
from typing import Optional
from jose import JWTError, jwt
from passlib.context import CryptContext
from uuid import uuid4
from datetime import datetime, timedelta
import os

from sqlalchemy import (
    create_engine, Column, String, Integer, JSON as SAJSON,
    ForeignKey, UniqueConstraint
)
from sqlalchemy.orm import sessionmaker, declarative_base, relationship
from sqlalchemy.exc import SQLAlchemyError

from services.parse_cad import CADParser

# --------------------------------------------------
# Configuración autenticación JWT
# --------------------------------------------------
SECRET_KEY = "your-secret-key-here"  # Cambiar por clave segura en entorno
ALGORITHM = "HS256"
ACCESS_TOKEN_EXPIRE_MINUTES = 30

pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")
oauth2_scheme = OAuth2PasswordBearer(tokenUrl="/token")

# --------------------------------------------------
# Base de datos
# --------------------------------------------------
DATABASE_URL = "sqlite:///./cvc.db"
engine = create_engine(
    DATABASE_URL, connect_args={"check_same_thread": False}
)
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)
Base = declarative_base()

class Project(Base):
    __tablename__ = "projects"
    id = Column(String, primary_key=True, index=True)
    filename = Column(String(255), nullable=False)
    vectors = relationship(
        "Vector", back_populates="project",
        cascade="all, delete", passive_deletes=True
    )
    __table_args__ = (
        UniqueConstraint("id", name="uq_project_id"),
    )

class Vector(Base):
    __tablename__ = "vectors"
    id = Column(Integer, primary_key=True, index=True)
    project_id = Column(
        String, ForeignKey("projects.id", ondelete="CASCADE"),
        nullable=False, index=True
    )
    data = Column(SAJSON, nullable=False)
    project = relationship("Project", back_populates="vectors")

class User(Base):
    __tablename__ = "users"
    username = Column(String, primary_key=True, index=True)
    full_name = Column(String(100), nullable=True)
    email = Column(String(100), unique=True, index=True)
    hashed_password = Column(String, nullable=False)
    disabled = Column(Integer, default=0)

# --------------------------------------------------
# Pydantic Schemas
# --------------------------------------------------
class Token(BaseModel):
    access_token: str
    token_type: str

class TokenData(BaseModel):
    username: str | None = None

class UserInDB(BaseModel):
    username: str
    email: Optional[str] = None
    full_name: Optional[str] = None
    hashed_password: str
    disabled: bool

class UserBase(BaseModel):
    username: str
    email: str | None = None
    full_name: str | None = None
    disabled: bool | None = None

# --------------------------------------------------
# Instanciar aplicación y directorios
# --------------------------------------------------
app = FastAPI(title="CNC VisionCut Backend")
UPLOAD_DIR = "uploads"
GCODE_DIR = "gcode"
ALLOWED_EXTENSIONS = {".dxf", ".svg", ".stl", ".obj"}
for d in (UPLOAD_DIR, GCODE_DIR):
    os.makedirs(d, exist_ok=True)

# --------------------------------------------------
# Helpers Auth
# --------------------------------------------------
def verify_password(plain_password, hashed_password):
    return pwd_context.verify(plain_password, hashed_password)

def get_password_hash(password):
    return pwd_context.hash(password)

def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

async def get_user(db, username: str) -> UserInDB | None:
    user = db.query(User).filter(User.username == username).first()
    if user:
        return UserInDB(**user.__dict__)
    return None

async def authenticate_user(db, username: str, password: str):
    user = await get_user(db, username)
    if not user or not verify_password(password, user.hashed_password):
        return False
    return user

async def create_access_token(data: dict, expires_delta: timedelta | None = None):
    to_encode = data.copy()
    expire = datetime.utcnow() + (expires_delta or timedelta(minutes=ACCESS_TOKEN_EXPIRE_MINUTES))
    to_encode.update({"exp": expire})
    return jwt.encode(to_encode, SECRET_KEY, algorithm=ALGORITHM)

async def get_current_user(token: str = Depends(oauth2_scheme), db=Depends(get_db)):
    credentials_exception = HTTPException(
        status_code=status.HTTP_401_UNAUTHORIZED,
        detail="Could not validate credentials",
        headers={"WWW-Authenticate": "Bearer"},
    )
    try:
        payload = jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
        username: str = payload.get("sub")
        if username is None:
            raise credentials_exception
        token_data = TokenData(username=username)
    except JWTError:
        raise credentials_exception
    user = await get_user(db, username=token_data.username)
    if user is None or user.disabled:
        raise HTTPException(status_code=400, detail="Inactive user")
    return user

# --------------------------------------------------
# Eventos de arranque
# --------------------------------------------------
@app.on_event("startup")
def startup_event():
    Base.metadata.create_all(bind=engine)
    global cad_parser
    cad_parser = CADParser(upload_dir=UPLOAD_DIR)

@app.post("/upload")
async def upload_file(
    file: UploadFile = File(...),
    db=Depends(get_db),
    current_user: UserBase = Depends(get_current_user)
):

# --------------------------------------------------
# Endpoints de Auth
# --------------------------------------------------
@app.post("/token", response_model=Token)
async def login_for_access_token(form_data: OAuth2PasswordRequestForm = Depends(), db=Depends(get_db)):
    user = await authenticate_user(db, form_data.username, form_data.password)
    if not user:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Incorrect username or password",
            headers={"WWW-Authenticate": "Bearer"},
        )
    access_token = await create_access_token(data={"sub": user.username})
    return {"access_token": access_token, "token_type": "bearer"}

# --------------------------------------------------
# Endpoint de registro de usuarios (signup)
# --------------------------------------------------
class UserCreate(BaseModel):
    username: str = Field(..., min_length=3, max_length=50)
    password: str = Field(..., min_length=6)
    email: str = Field(...)
    full_name: str | None = None

@app.post("/signup", response_model=UserBase)
async def signup(user_in: UserCreate, db=Depends(get_db)):
    # Verificar que el usuario no exista
    existing_user = db.query(User).filter(
        (User.username == user_in.username) | (User.email == user_in.email)
    ).first()
    if existing_user:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Username or email already registered"
        )
    # Crear usuario con contraseña hasheada
    hashed_password = get_password_hash(user_in.password)
    user = User(
        username=user_in.username,
        email=user_in.email,
        full_name=user_in.full_name,
        hashed_password=hashed_password,
        disabled=0
    )
    db.add(user)
    db.commit()
    # Devolver datos públicos
    return UserBase(
        username=user.username,
        email=user.email,
        full_name=user.full_name,
        disabled=bool(user.disabled)
    )

# --------------------------------------------------
# Endpoints protegidos de ejemplo
# --------------------------------------------------
@app.get("/users/me", response_model=UserBase)
async def read_users_me(current_user: UserBase = Depends(get_current_user)):
    return current_user

# --------------------------------------------------

